1793339281 /home/student/cadWorkDir/myProjects/Digital/1BF24EC185/sim1/RTL/parity_4bit.v
1793339846 /home/student/cadWorkDir/myProjects/Digital/1BF24EC185/sim1/tb/test_counter.v
