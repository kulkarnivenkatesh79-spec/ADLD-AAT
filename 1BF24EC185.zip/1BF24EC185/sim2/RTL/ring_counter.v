module ring_counter (input clk, rst, output reg [3:0] q);
always @(posedge clk or posedge rst)
if (rst) q <= 4'b0001;
else q <= {q[0], q[3:1]};
endmodule
